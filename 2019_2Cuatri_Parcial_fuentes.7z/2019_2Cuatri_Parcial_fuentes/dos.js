function mostrar()
{
  var nombre;
  var animal;
  var peso;
  var edad;
  var contPeso = 0;
  var promP;
  var acumPeso = 0;
  var aniMax;
  var contMenor = 0;
  var edadMax;
  var flag = 0;
  var rta;

  do {
    //pido animal
    animal = prompt("(ingrese si es 'perro' o 'gato')");
    while (animal != "perro" && animal != "gato") {
      animal = prompt("(Error. reingrese si es 'perro' o 'gato')");
    }
    //pido peso
    peso = parseInt(prompt("ingrese el peso entre 1 y 100"));
    while (isNaN(peso) || peso < 1 || peso > 100) {
      peso = parseInt(prompt("reingrese el peso entre 1 y 100"));
    }
    //pido edad
    edad = parseInt(prompt("ingrese la edad del animal entre 1 a 25"));
    while (isNaN(edad) || edad < 1 || edad > 25) {
      edad = parseInt(prompt("Reingrese la edad del animal entre 1 a 25"));
    }
    //pido nombre
    nombre = prompt("Ingrese el Nombre de la mascota.")
    if (animal == "perro" && edad > edadMax || flag < 1) {
      flag++;
      edadMax = edad;
      aniMax = nombre;
    }
    if (edad > 10 && peso < 10) {
      contMenor++;
    }
    contPeso++;
    acumPeso += peso;
    rta = prompt("desea ingresar otra mascota? 's' para continuar");
  } while (rta == "s")

  promP = acumPeso / contPeso;

  alert("a) El promedio de los pesos totales es de " + promP);
  alert("b) El nombre del perro mas viejo es " + aniMax);
  alert("c) La cantidad animales menores a 10 kilos de mas de 10 años es de " + contMenor);

}
