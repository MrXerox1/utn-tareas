function mostrar() {
  var ciudad;
  var habitantes;
  var temp;
  var temppar = 0;
  var tempMin;
  var tempMax = 0;
  var contHabi = 0;
  var promHabi;
  var acumHabi = 0;
  var ciudadtemp;
  var ciudadMin;
  var max;
  var min;
  var flag = 0;
  var bandera = 0;
  var rta;

  do {
    ciudad = prompt("(ingrese el nombre de la ciudad)");
    habitantes = parseInt(prompt("ingrese un numero entre 1 millon y 40 millones"));
    while (isNaN(habitantes) || habitantes < 1000000 || habitantes > 40000000) {
      habitantes = parseInt(prompt("Reingrese un numero entre 1 millon y 40 millones"));
    }
    temp = parseInt(prompt("ingrese un numero entre -50 y 50"));
    while (isNaN(temp) || temp < -50 || temp > 50) {
      temp = parseInt(prompt("Reingrese un numero entre -50 y 50"));
    }
    if (temp % 2 == 0) {
      temppar++;
    }
    if (habitantes < min || flag < 1) {
      flag++;
      min = habitantes;
      ciudadMin = ciudad;
    }
    if (temp < tempMin || bandera != 1) {
      bandera++
      tempMin = temp;
      ciudadtemp = ciudad;
    }
    if (temp > 40) {
      tempMax++
    }
    acumHabi = acumHabi + habitantes;
    contHabi++
    rta = prompt("desea ingresar otro ciudad? 's' para continuar");
  } while (rta == "s")
  promHabi = acumHabi / contHabi;
  document.write("a) La cantidad de temperaturas pares es de " + temppar + "<br>");
  document.write("b) El nombre de la localidad con menos habitantes es " + ciudadMin + "<br>");
  document.write("c) La cantidad localidades que superan los 40 grados de temperatura es de " + tempMax + "<br>");
  document.write("d) El promedio de habitantes entre las localidades ingresadas es " + promHabi + "<br>");
  document.write("e)La temperatura mínima ingresada es de " + tempMin + " y nombre de la localidad que registro esa temperatura es " + ciudadtemp);
}
