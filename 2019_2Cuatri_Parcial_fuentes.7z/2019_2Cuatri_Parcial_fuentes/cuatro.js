function mostrar()
{
  var letra;
  var numero;
  var promP;
  var contPar = 0;
  var contInp = 0;
  var contCero = 0;
  var contPos = 0;
  var contNeg = 0;
  var acumPos = 0;
  var sumaNeg = 0;
  var letraMax;
  var letraMin;
  var max;
  var min;
  var flag = 0;
  var rta;

  do {
    letra = prompt("(ingrese una letra)");

    do {
      numero = parseInt(prompt("ingrese un numero entre -100 y 100"));
    } while (isNaN(numero) || numero < -100 || numero > 100);

    if (numero % 2 == 0 && numero != 0) {
      contPar++;
    }
    else if (numero == 0) {
      contCero++;
    }
    else {
      contInp++;
    }
    if (numero >= 0) {
      contPos++;
      acumPos += numero;
    }
    else {
      contNeg++;
      sumaNeg += numero;
    }
    if (flag < 1) {
      flag++;
      min = numero
      max = numero;
      letraMin = letra;
      letraMax = letra;
    } else {
      if (numero > max) {
        max = numero;
        letraMax = letra;
      } else if (numero < min) {
        min = numero;
        letraMin = letra;
      }
    }
    rta = prompt("desea ingresar otro numero");
  } while (rta == "s")
  promP = acumPos / contPos;
  document.write("a) La cantidad de números pares es " + contPar + "<br>");
  document.write("b) La cantidad de números impares es " + contInp + "<br>");
  document.write("c) La cantidad de ceros es " + contCero + "<br>");
  document.write("d) El promedio de todos los números positivos ingresados " + promP + "<br>");
  document.write("e) La suma de todos los números negativos " + sumaNeg + "<br>");
  document.write("f) la letra máxima es " + letraMax + "  y el número maximo es " + max + "<br>" + "La letra mínimo es " + letraMin + " y el numero minimo es " + min);
}
